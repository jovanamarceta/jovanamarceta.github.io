let gulp = require('gulp');
const uglify = require('gulp-uglify-es').default;
const concat = require('gulp-concat');
const sass = require('gulp-sass');
const autoprefixer = require('gulp-autoprefixer');
const yml = require('gulp-yml');
const browserSync = require('browser-sync').create();


// copy html files
function copyHTML() {
    return gulp.src("src/*.html")
        .pipe(gulp.dest("dist"));
}

// minify and concat js
function scripts() {
    return gulp.src("src/js/*.js")
        .pipe(concat("script.js"))
        .pipe(uglify())
        .pipe(gulp.dest("dist/js"));
}

// compile scss into css
function style() {
    // find scss file
    return gulp.src('./src/scss/**/*.scss')
    // pass scss file through sass compiler
    .pipe(sass().on('error', sass.logError))
    .pipe(autoprefixer({
        browsers: ['last 2 versions'],
        cascade: false
    }))
    // where to save the compiled css
    .pipe(gulp.dest('./dist/css'))
    // stream changes to all browser
    .pipe(browserSync.stream());
}

// move .json
function data() {
    gulp.src('src/data/**/*')
        .pipe(yml())
        .pipe(gulp.dest("dist/data"));
}

// move fonts
function fonts() {
    gulp.src("src/fonts/*")
        .pipe(gulp.dest("dist/fonts"));
}

// watch for changes and update
function watch() {
    browserSync.init({
        server: {
            baseDir: './'
        }
    });
    gulp.watch('src/scss/**/*.scss', style);
    gulp.watch('dist/**/*.html').on('change', browserSync.reload);
    gulp.watch('dist/js/**/*.js').on('change', browserSync.reload);
}


exports.copyHTML = copyHTML;
exports.scripts = scripts;
exports.data = data;
exports.fonts = fonts;
exports.style = style;
exports.watch = watch;
